// async function val(){
//   try{
//     const response = await fetch ('https://sheetdb.io/api/v1/7xc9eekm4gezj?&limit=5&offset=0');
//     const data= await response.json();
//     return data;
//   } catch(error){
//     alert(error);
//   }
// }
var ADc=[0,
  30,
  100,
  150,
  200];  var ADt=[5,
    35, 
    140,
    200,
    250];
  
var BCc=[0,
  35,
  75,
  110,
  170];  var BCt=[9,
    55,
    100,
    160,
    230];

var BEc=[0,
  32,
  79,
  110,
  180,];  var BEt=[4,
    53,
    119,
    170,
    260];

var CGc=[0,
  40,
  78,
  120,
  170];  var CGt=[7,
    75,
    128,
    170,
    235];

var DFc=[0,
  34,
  72,
  109,
  168];  var DFt=[8,
    56,
    109,
    169,
    234];

var ACc=[0,
  37,
  68,
  99,
  167];  var ACt=[9,
    70,
    115,
    179,
    269];
console.log(ACt);

// var value = val().then((value)=>{
//   // console.log(value);
//   for(let key in value){
//     // console.log(key);
//     // console.log(value[key]);
//     for(let arr in value[key]){
//       if(arr.toString()=="ADc"){
//         // console.log('r');
//         ADc.push(value[key][arr]);
//       }
//       else if(arr.toString()=="ADt"){
//         ADt.push(value[key][arr]);
//       }
//       else if(arr.toString()=="BCc"){
//         BCc.push(value[key][arr]);
//       }
//       else if(arr.toString()=="BCt"){
//         BCt.push(value[key][arr]);
//       }
//       else if(arr.toString()=="BEc"){
//         BEc.push(value[key][arr]);
//       }
//       else if(arr.toString()=="BEt"){
//         BEt.push(value[key][arr]);
//       }
//       else if(arr.toString()=="CGc"){
//         CGc.push(value[key][arr]);
//       }
//       else if(arr.toString()=="CGt"){
//         CGt.push(value[key][arr]);
//       }
//       else if(arr.toString()=="DFc"){
//         DFc.push(value[key][arr]);
//       }
//       else if(arr.toString()=="DFt"){
//         DFt.push(value[key][arr]);
//       }
//       else if(arr.toString()=="ACc"){
//         ACc.push(value[key][arr]);
//       }
//       else if(arr.toString()=="ACt"){
//         ACt.push(value[key][arr]);
//       }
//       // console.log(value[key][arr]);
//     }
//     // ADcount.push(value[key]);
//     // if(value.hasOwnProperty(key)){
//     //   if(key=="ADc"){ }
//     // }
//   }
//   console.log(ACt);

// });



//After taking value for roadfunction
var cnum;//data from user


//NMST
function NMST(x,ax,ay){
  var n=5,i,j; //Number of terms & Loop Variables
  var y=0; //time for current number of cars

  //Lagrange's Interpolation
  let p;
  for(i=0;i<n;i++){
    p=1;
    for(j=0;j<n;j++){
      if(j!=i){
        p=p*((x-ax[j]))/((ax[i]-ax[j]));
      }
    }
    y+=p*ay[i];
  }
  // console.log(y);
  return y;
  
}


/*Next Best Calculator*/ 
var string="";
flag=0;
function setup() {
  createCanvas(550, 550);
}
///////////////////////////////////////initial values +cnum to pass
function toAD(n,ADc,ADt){
  return NMST(n,ADc,ADt);
}
function toBC(n,BCc,BCt){
  return NMST(n,BCc,BCt);
}
function toBE(n,BEc,BEt){
  return NMST(n,BEc,BEt);
}
function toCG(n,CGc,CGt){
  return NMST(n,CGc,CGt);
}
function toDF(n,DFc,DFt){
  return NMST(n,DFc,DFt);
}
function toAC(n,ACc,ACt){
  return NMST(n,ACc,ACt);
}

function exitTraffic(n){
  if(n<=30){
    n/=1.2;
  }
  else if( 50>=n && n>30){
    n/=1.351;
  }
  else if(50<n&&n<=100){
    n/=1.45;
  }
  else if(100<n<=200){
    n/=2;
  }
  else{n/=3;}
  return n;
}

var exAD=0,exBC=0,exBE=0,exCG=0,exDF=0,exAC=0;
var prev=0;
function solve(){
  var n=cnum;  
  
//to get answer for highway
// =funcl(prethinl-=left);//NMST=funcr(prethinr-=right);//NMST
    // cout<<prethinl<<" "<<left<<endl;
    // cout<<prethinr<<" "<<right<<endl;


//thin road approximation using nmst
if(flag==0)//first calling
{  var AD=toAD(n,ADc,ADt);
  var BC=toBC(n,BCc,BCt);
  var BE=toBE(n,BEc,BEt);
  var CG=toCG(n,CGc,CGt);
  var DF=toDF(n,DFc,DFt);
  var AC=toAC(n,ACc,ACt);
  if(AD<=0) AD=2;
  if(BC<=0) BC=3;
  if(BE<=0) BE=3;
  if(CG<=0) CG=4;
  if(DF<=0) DF=4;
  if(AC<=0) AC=3;
  prev=n;
}
else{
  var AD=toAD(n-exAD+prev,ADc,ADt);
  
  var BC=toBC(n-exBC+prev,BCc,BCt);
  
  var BE=toBE(n-exBE+prev,BEc,BEt);
  
  var CG=toCG(n-exCG+prev,CGc,CGt);
  
  var DF=toDF(n-exDF+prev,DFc,DFt);
  
  var AC=toAC(n-exAC+prev,ACc,ACt);
  if(AD<=0) AD=2;
  if(BC<=0) BC=3;
  if(BE<=0) BE=3;
  if(CG<=0) CG=4;
  if(DF<=0) DF=4;
  if(AC<=0) AC=3;
  prev=n;
}
  var AB=37,DC=29,EG=44,FG=40;



// Dijkistra's Algo
let graph = {
	A: { B: AB, C: AC, D: AD },
	B: { A: AB, C: BC, E: BE },
	C: { A: AC, B: BC, D: DC, G: CG },
	D: { A: AD, C: DC, F: DF },
	E: { B: BE, G: EG },
	G: { E: EG, F: FG },
  F: { D: DF, G: FG },
};

  let shortestDistanceNode = (distances, visited) => {
    // create a default value for shortest
      let shortest = null;
      
        // for each node in the distances object
      for (let node in distances) {
          // if no node has been assigned to shortest yet
            // or if the current node's distance is smaller than the current shortest
          let currentIsShortest =
              shortest === null || distances[node] < distances[shortest];
              
            // and if the current node is in the unvisited set
          if (currentIsShortest && !visited.includes(node)) {
              // update shortest to be the current node
              shortest = node;
          }
      }
      return shortest;
      
  };

  let findShortestPath = (graph, startNode, endNode) => {

    // track distances from the start node using a hash object
      let distances = {};
    distances[endNode] = "Infinity";
    distances = Object.assign(distances, graph[startNode]);
   // track paths using a hash object
    let parents = { endNode: null };
    for (let child in graph[startNode]) {
      parents[child] = startNode;
    }

    // collect visited nodes
      let visited = [];
   // find the nearest node
      let node = shortestDistanceNode(distances, visited);
    
    // for that node:
    while (node) {
    // find its distance from the start node & its child nodes
      let distance = distances[node];
      let children = graph[node]; 

    // for each of those child nodes:
          for (let child in children) {

     // make sure each child node is not the start node
          if (String(child) === String(startNode)) {
            continue;
          } else {
             // save the distance from the start node to the child node
            let newdistance = distance + children[child];
   // if there's no recorded distance from the start node to the child node in the distances object
   // or if the recorded distance is shorter than the previously stored distance from the start node to the child node
            if (!distances[child] || distances[child] > newdistance) {
   // save the distance to the object
        distances[child] = newdistance;
   // record the path
        parents[child] = node;
      } 
            }
          }  
         // move the current node to the visited set
        visited.push(node);
   // move to the nearest neighbor node
        node = shortestDistanceNode(distances, visited);
      }
    
    // using the stored paths from start node to end node
    // record the shortest path
    let shortestPath = [endNode];
    let parent = parents[endNode];
    while (parent) {
      shortestPath.push(parent);
      parent = parents[parent];
    }
    shortestPath.reverse();
    
    // document.write("this is the shortest distance: ");
    // document.write(distances[endNode]);
    // document.write("<br>");
    // document.write("this is the path-way: ");
    // document.write(shortestPath);
    let results = {
      time: distances[endNode],
      path: shortestPath,
    };
    // return the shortest path & the end node's distance from the start node
      return results;
  };
  patharr=findShortestPath(graph, "A", "G");
  console.log(patharr);
  for(var i=0;i<patharr.path.length;i++){
    string+=(patharr.path[i].toString());
  }
  console.log(string);
  exAD=exitTraffic(n),exBC=exitTraffic(n),exBE=exitTraffic(n),exCG=exitTraffic(n),exDF=exitTraffic(n),exAC=exitTraffic(n);
  document.getElementById('path').innerText=string;
  document.getElementById("time").innerText=patharr.time;
}

// console.log(8);
// console.log(string);

let i=0;

let circleX=250;
let circleY=80;
let d=-1;
let s=0;

function draw(){
  let stringCheck=string;
  let n=stringCheck.length-1;
  if(stringCheck!=""){
    background(176, 230, 176);
    make(); 
    if(i<n){
      let str1=stringCheck[i];
      let str2=stringCheck[i+1];
      if(str1=='A'&&str2=='B'){
        if(s==0){
          circleX=250;
          circleY=80;
          d=0;
        }
        if(d==0){
          main12();
        }
        else{
          s=0;
        }
      }
      if(str1=='A'&&str2=='D'){
        if(s==0){
          circleX=250;
          circleY=80;
          d=7;
        }
        if(d==7){
          main14();
        }
      }
      if(str1=='A'&&str2=='C'){
        if(s==0){
          circleX=250;
          circleY=80;
          d=8;
        }
        if(d==8){
          main13();
        }
      }
      if(str1=='B'&&str2=='C'){
        if(s==0){
          circleX=100;
          circleY=220;
          d=1;
        }
        if(d==1){
          main23();
        }
      }
      if(str1=='E'&&str2=='B'){
        if(s==0){
          circleX=100;
          circleY=325;
          d=6;
        }
        if(d==6){
          main52();
        }
      }
      if(str1=='C'&&str2=='D'){
        if(s==0){
          circleX=250;
          circleY=220;
          d=2;
        }
        if(d==2){
          main34();
        }
      }
      if(str1=='D'&&str2=='F'){
        if(s==0){
          circleX=400;
          circleY=220;
          d=3;
        }
        if(d==3){
          main46();
        }
      }
      if(str1=='F'&&str2=='G'){
        if(s==0){
          circleX=400;
          circleY=325;
          d=4;
        }
        if(d==4){
          main67();
        }
      }
      if(str1=='G'&&str2=='E'){
        if(s==0){
          circleX=250;
          circleY=450;
          d=5;
        }
        if(d==5){
          main75();
        }
      }
      if(str1=='C'&&str2=='G'){
        if(s==0){
          circleX=250;
          circleY=220;
          d=9;
        }
        if(d==9){
          main37();
        }
      }
      if(str1=='B'&&str2=='A'){
        if(s==0){
          circleX=100;
          circleY=220;
          d=10;
        }
        if(d==10){
          main21();
        }
      }
      if(str1=='C'&&str2=='B'){
        if(s==0){
          circleX=250;
          circleY=220;
          d=11;
        }
        if(d==11){
          main32();
        }
    
      }
      if(str1=='D'&&str2=='C'){
        if(s==0){
          circleX=400;
          circleY=220;
          d=12;
        }
        if(d==12){
          main43();
        }
    
      }
      if(str1=='G'&&str2=='F'){
        if(s==0){
          circleX=250;
          circleY=450;
          d=14;
        }
        if(d==14){
          main76();
        }
    
      }
      if(str1=='E'&&str2=='G'){
        if(s==0){
          circleX=100;
          circleY=325;
          d=15;
        }
        if(d==15){
          main57();
        }
    
      }
      if(str1=='B'&&str2=='E'){
        if(s==0){
          circleX=100;
          circleY=220;
          d=16;
        }
        if(d==16){
          main25();
        }
    
      }
      if(str1=='D'&&str2=='A'){
        if(s==0){
          circleX=400;
          circleY=220;
          d=17;
        }
        if(d==17){
          main41();
        }
    
      }
      if(str1=='C'&&str2=='A'){
        if(s==0){
          circleX=250;
          circleY=220;
          d=18;
        }
        if(d==18){
          main31();
        }
    
      }
      if(str1=='G'&&str2=='C'){
        if(s==0){
          circleX=250;
          circleY=450;
          d=19;
        }
        if(d==19){
          main73();
        }
    
      }
      if(str1=='F'&&str2=='D'){
        if(s==0){
          circleX=400;
          circleY=325;
          d=20;
        }
        if(d==20){
          main64();
        }
    
      }
    }
  }
}
//main23();
let speed=2;
function make() {
  
  line(250, 80, 250, 220);
  line(250, 80, 400, 220);
  line(100, 220, 250, 220);
  line(100, 220, 100, 325);
  line(250, 220, 250, 450);
  line(400, 220, 400, 325);
  strokeWeight(10);
  line(250, 80, 100, 220);
  line(250, 220, 400, 220);
  line(100, 325, 250, 450);
  line(400, 325, 250, 450);
  strokeWeight(1);
  rectMode(CENTER);
  fill(220, 0, 0);
  rect(250, 80, 30, 30);
  rect(250, 220, 30, 30);
  rect(250, 450, 30, 30);
  rect(100, 220, 30, 30);
  rect(400, 220, 30, 30);
  rect(100, 325, 30, 30);
  rect(400, 325, 30, 30);

  textSize(25);
  fill(0, 0, 0);
  text("A", 242, 89);
  text("B", 93, 228);
  text("C", 242, 228);
  text("D", 392, 228);
  text("E", 93, 333);
  text("F", 392, 333);
  text("G", 242, 458);
}

function main12(){
  if(circleX<=100||circleY>=220){
    //noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("1");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX-=speed;
  circleY+=speed;
  
}
function main23(){
  if(circleX>=250){
    //noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("2");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX+=speed;
}
function main34(){
  if(circleX>=400){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  print("3");
  s=1;
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX+=speed;
  
}
function main46(){
  if(circleY>=325){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("4");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY+=speed;
  
}
function main67(){
  if(circleY>=450||circleX<=250){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("5");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX-=speed;
  circleY+=speed;
  
}
function main75(){
  if(circleY<=325||circleX<=100){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("6");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX-=speed;
  circleY-=speed;
  
}
function main52(){
  if(circleY<=220){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("7");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY-=speed;
  
}
function main14(){
  if(circleX>=400||circleY>=220){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("8");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX+=speed;
  circleY+=speed;
  
}
function main13(){
  if(circleY>=220){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s++;
  print("9");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY+=speed;
  
}
function main37(){
  if(circleY>=450){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("10");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY+=speed; 
}
function main21(){
  if(circleY<=80||circleX>=250){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("11");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY-=speed;
  circleX+=speed;
}
function main32(){
  if(circleX<=100){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("12");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX-=speed; 
}
function main43(){
  if(circleX<=250){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("13");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX-=speed; 
}
function main64(){
  if(circleY<=220){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("14");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY-=speed; 
}
function main76(){
  if(circleX>=400||circleY<=325){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("15");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX+=speed;
  circleY-=speed;
}
function main57(){
  if(circleX>=250||circleY>=450){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("16");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX+=speed;
  circleY+=speed;
}
function main25(){
  if(circleY>=325){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("17");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY+=speed; 
}
function main41(){
  if(circleX<=250||circleY<=80){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("18");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleX-=speed;
  circleY-=speed;
}
function main31(){
  if(circleY<=80){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("19");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY-=speed; 
}
function main73(){
  if(circleY<=220){
   // noLoop();
    s=0;
    d=-1;
    i++;
    return;
  }
  s=1;
  print("20");
  fill(0,0,190);
  circle(circleX,circleY,25);
  circleY-=speed; 
}



function getInput(){
  string="";
  cnum=document.getElementById("carnum").value;
  i=0;
  circleX=250;
  circleY=80;
  d=-1;
  s=0;
  solve();  flag=1;

}