// function funcl( n){
//     return (n/5.0)+4;
//   }
  
//   function funcr( n){
//     return (n/12.0)+7;
//   }
var ADc=[0,
  30,
  100,
  150,
  200];  var ADt=[5,
    35, 
    140,
    200,
    250];
    var CBc=[0,
      35,
      75,
      110,
      170];  var CBt=[9,
        55,
        100,
        160,
        230];
  
  function NMST(x,ax,ay){
    var n=5,i,j; //Number of terms & Loop Variables
    var y=0; //time for current number of cars
  
    //Lagrange's Interpolation
    let p;
    for(i=0;i<n;i++){
      p=1;
      for(j=0;j<n;j++){
        if(j!=i){
          p=p*((x-ax[j]))/((ax[i]-ax[j]));
        }
      }
      y+=p*ay[i];
    }
    // console.log(y);
    return y;
    
  }
  function trafficelimination( n){
    if(n<=100){
      n/=1.2;
    }
    else if(n>100){
      n/=2;
    }
    else if(n>500){
      n/=3;
    }
    else{
      n/=10;
    }
    return n;
  }
  

  function solve(){
    var limit=paradox();
    if(limit!=-1) {document.getElementById("limit").innerText="Average Traffic Limit: " + limit};
    var flag=1;
  
    var x=1;  
    var mapApi=25;//to get answer for highway
    var midroad=2;
    var prethinl=document.getElementById("NOVLR").value;
    var prethinr=document.getElementById("NOVRR").value;
    var thickroad=mapApi;
    // var lb=1,ub=50;
    var z=document.getElementById("NOV").value;
    var left=0,right=0;
      // console.log(prethinl+" "+left+endl;
      // console.log(prethinr+" "+right+endl;
    var thinroadl=NMST(prethinl-=left,ADc,ADt);//NMST
    var thinroadr=NMST(prethinr-=right,CBc,CBt);//NMST
  
    var thickRThinR=thinroadr+thickroad;
    var thickLThinL=thinroadl+thickroad;
  
    var onlythin=thinroadl+thinroadr+midroad;
    var onlythick=thickroad*2+midroad;
    
    var mini=thickRThinR;
  
    if(mini>thickLThinL) mini=thickLThinL;
    if(mini>onlythin) mini=onlythin;
    if(mini>onlythick) mini=onlythick;
    
    if(mini==thickRThinR) {prethinr+=x;flag=1;}
    else if(mini==thickLThinL) {prethinl+=x;flag=2;}
    else if(mini== onlythin) {prethinl+=x;prethinr+=x;flag=3;}
    else flag=4;
    if(flag==4)
    console.log("thickRThinR: "+  thickRThinR);
    console.log("thickLThinL: "+thickLThinL);
    console.log("onlythin: "+onlythin);
    console.log("onlythick: "+onlythick);
  
    if(flag==1)   document.getElementById("data").innerHTML =("MinTime: "+mini.toPrecision(4)+" "+ "Minimum Path: thickRThinR"); 
    else if(flag==2)  document.getElementById("data").innerHTML =("MinTime: "+mini.toPrecision(4)+ " "+"Minimum Path::thickLThinL");
    else if(flag==3) document.getElementById("data").innerHTML =("MinTime: "+mini.toPrecision(4)+ " "+ "Minimum Path: onlythin"); 
    else if(flag==4)  document.getElementById("data").innerHTML =("MinTime "+mini.toPrecision(4)+ " "+"Minimum Path: onlythick"); 
  

    if(flag==1)   document.getElementById("verdict").innerHTML =("NO, RED WILL NOT REDUCE THE TRAFFIC."); 
    else if(flag==2)  document.getElementById("verdict").innerHTML =("NO, IT WONT'T REDUCE THE TRAFFIC.");
    else if(flag==3) document.getElementById("verdict").innerHTML =("YES, WE NEED TO CONSTRUCT THIS ROAD TO REDUCE TRAFFIC"); 
    else if(flag==4)  document.getElementById("verdict").innerHTML =("YES, WE NEED TO CONSTRUCT THIS ROAD TO REDUCE TRAFFIC"); 
    
  
    
    // console.log("x: "+x );
    //   x=(rand() % (ub - lb + 1)) + lb;
    //   left=trafficelimination(thinroadl);
    //   right = trafficelimination(thinroadr);
    //   z++;
  
  
  }
  function average( a, b){
    return (a+b)/2.0;
  }
function paradox(){
    var n=1;
    while(n<=500){
    var thickroad=25;
    var midroad=2;
    var thinroadl=NMST(n,ADc,ADt);//NMST
    var thinroadr=NMST(n,CBc,CBt);//NMST
    var onlythin=thinroadl+thinroadr+midroad;
    var alternater=NMST(n/2,ADc,ADt)+thickroad;
    var alternatel=NMST(n/2,CBc,CBt)+thickroad;
    var alt=average(alternatel,alternater);
    // console.log("onlythin: "+onlythin+"  ");
    if(onlythin>alt) break;
      n++;
    }
    if(n==500) return -1;
    return n;
}


    

    function setup() {
        createCanvas(600, 500);
      }
      
      function draw() {
        background(18, 80, 120);
        strokeWeight(8);
        stroke(255, 255, 0);
        line(100, 250, 290, 345);
        line(300, 135, 500, 250);
        strokeWeight(20);
        stroke(127, 255, 0);
        line(100, 250, 300, 135);
        line(290, 345, 500, 250);
        stroke(255, 0, 0);
        line(300, 135, 290, 345);
        strokeWeight(5);
        stroke(0, 0, 0);
        fill(255, 140, 0);
        circle(100, 250, 50);
        circle(500, 250, 50);
        circle(300, 135, 40);
        circle(290, 345, 40);
        strokeWeight(1);
        textSize(25);
        fill(0, 0, 0);
        text("A", 93, 255);
        text("B", 492, 257);
        text("C", 293, 142);
        text("D", 282, 352);
      }
      