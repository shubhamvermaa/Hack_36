async function val(){
  try{
    const response = await fetch ('https://sheetdb.io/api/v1/7xc9eekm4gezj?&limit=5&offset=0');
    const data= await response.json();
    return data;
  } catch(error){
    alert(error);
  }
}
var ADc=[];  var ADt=[];
  
var BCc=[];  var BCt=[];

var BEc=[];  var BEt=[];

var CGc=[];  var CGt=[];

var DFc=[];  var DFt=[];

var ACc=[];  var ACt=[];

var value = val().then((value)=>{
  // console.log(value);
  for(let key in value){
    // console.log(key);
    // console.log(value[key]);
    for(let arr in value[key]){
      if(arr.toString()=="ADc"){
        // console.log('r');
        ADc.push(value[key][arr]);
      }
      else if(arr.toString()=="ADt"){
        ADt.push(value[key][arr]);
      }
      else if(arr.toString()=="BCc"){
        BCc.push(value[key][arr]);
      }
      else if(arr.toString()=="BCt"){
        BCt.push(value[key][arr]);
      }
      else if(arr.toString()=="BEc"){
        BEc.push(value[key][arr]);
      }
      else if(arr.toString()=="BEt"){
        BEt.push(value[key][arr]);
      }
      else if(arr.toString()=="CGc"){
        CGc.push(value[key][arr]);
      }
      else if(arr.toString()=="CGt"){
        CGt.push(value[key][arr]);
      }
      else if(arr.toString()=="DFc"){
        DFc.push(value[key][arr]);
      }
      else if(arr.toString()=="DFt"){
        DFt.push(value[key][arr]);
      }
      else if(arr.toString()=="ACc"){
        ACc.push(value[key][arr]);
      }
      else if(arr.toString()=="ACt"){
        ACt.push(value[key][arr]);
      }
      // console.log(value[key][arr]);
    }
    // ADcount.push(value[key]);
    // if(value.hasOwnProperty(key)){
    //   if(key=="ADc"){ }
    // }
  }
  console.log(ACt);

});



//After taking value for roadfunction
var cnum;//data from user


//NMST
function NMST(x,ax,ay){
  var n=5,i,j; //Number of terms & Loop Variables
  var y=0; //time for current number of cars

  //Lagrange's Interpolation
  let p;
  for(i=0;i<n;i++){
    p=1;
    for(j=0;j<n;j++){
      if(j!=i){
        p=p*(x-ax[j])/(ax[i]-ax[j]);
      }
    }
    y+=p*ay[i];
  }
  console.log(y);
  return y;
  
}


/*Next Best Calculator*/ 
flag=0;

///////////////////////////////////////initial values +cnum to pass
function toAD(n,ADc,ADt){
  return NMST(n,ADc,ADt);
}
function toBC(n,BCc,BCt){
  return NMST(n,BCc,BCt);
}
function toBE(n,BEc,BEt){
  return NMST(n,BEc,BEt);
}
function toCG(n,CGc,CGt){
  return NMST(n,CGc,CGt);
}
function toDF(n,DFc,DFt){
  return NMST(n,DFc,DFt);
}
function toAC(n,ACc,ACt){
  return NMST(n,ACc,ACt);
}

function exitTraffic(n){
  if(n<=30){
    n/=1.2;
  }
  else if( 50>=n && n>30){
    n/=1.351;
  }
  else if(50<n&&n<=100){
    n/=1.45;
  }
  else if(100<n<=200){
    n/=2;
  }
  else{n/=3;}
  return n;
}

var exAD=0,exBC=0,exBE=0,exCG=0,exDF=0,exAC=0;
var prev;
function solve(){
  var n=cnum;  
  
//to get answer for highway
// =funcl(prethinl-=left);//NMST=funcr(prethinr-=right);//NMST
    // cout<<prethinl<<" "<<left<<endl;
    // cout<<prethinr<<" "<<right<<endl;


//thin road approximation using nmst
if(flag==0)
{  var AD=toAD(n-exAD,ADc,ADt);
  var BC=toBC(n-exBC,BCc,BCt);
  var BE=toBE(n-exBE,BEc,BEt);
  var CG=toCG(n-exCG,CGc,CGt);
  var DF=toDF(n-exDF,DFc,DFt);
  var AC=toAC(n-exAC,ACc,ACt);
  prev=n;
}
else{
  var AD=toAD(n-exAD+prev,ADc,ADt);
  var BC=toBC(n-exBC+prev,BCc,BCt);
  var BE=toBE(n-exBE+prev,BEc,BEt);
  var CG=toCG(n-exCG+prev,CGc,CGt);
  var DF=toDF(n-exDF+prev,DFc,DFt);
  var AC=toAC(n-exAC+prev,ACc,ACt);
  prev=n;
}
  var AB=37,DC=29,EG=44,FG=40;



// Dijkistra's Algo
let graph = {
	A: { B: AB, C: AC, D: AD },
	B: { A: AB, C: BC, E: BE },
	C: { A: AC, B: BC, D: DC, G: CG },
	D: { A: AD, C: DC, F: DF },
	E: { B: BE, G: EG },
	G: { E: EG, F: FG },
  F: { D: DF, G: FG },
};

let shortestDistanceNode = (distances, visited) => {
    // create a default value for shortest
      let shortest = null;
      
        // for each node in the distances object
      for (let node in distances) {
          // if no node has been assigned to shortest yet
            // or if the current node's distance is smaller than the current shortest
          let currentIsShortest =
              shortest === null || distances[node] < distances[shortest];
              
            // and if the current node is in the unvisited set
          if (currentIsShortest && !visited.includes(node)) {
              // update shortest to be the current node
              shortest = node;
          }
      }
      return shortest;
  };

  let findShortestPath = (graph, startNode, endNode) => {

    // track distances from the start node using a hash object
      let distances = {};
    distances[endNode] = "Infinity";
    distances = Object.assign(distances, graph[startNode]);
   // track paths using a hash object
    let parents = { endNode: null };
    for (let child in graph[startNode]) {
      parents[child] = startNode;
    }

    // collect visited nodes
      let visited = [];
   // find the nearest node
      let node = shortestDistanceNode(distances, visited);
    
    // for that node:
    while (node) {
    // find its distance from the start node & its child nodes
      let distance = distances[node];
      let children = graph[node]; 

    // for each of those child nodes:
          for (let child in children) {

     // make sure each child node is not the start node
          if (String(child) === String(startNode)) {
            continue;
          } else {
             // save the distance from the start node to the child node
            let newdistance = distance + children[child];
   // if there's no recorded distance from the start node to the child node in the distances object
   // or if the recorded distance is shorter than the previously stored distance from the start node to the child node
            if (!distances[child] || distances[child] > newdistance) {
   // save the distance to the object
        distances[child] = newdistance;
   // record the path
        parents[child] = node;
      } 
            }
          }  
         // move the current node to the visited set
        visited.push(node);
   // move to the nearest neighbor node
        node = shortestDistanceNode(distances, visited);
      }
    
    // using the stored paths from start node to end node
    // record the shortest path
    let shortestPath = [endNode];
    let parent = parents[endNode];
    while (parent) {
      shortestPath.push(parent);
      parent = parents[parent];
    }
    shortestPath.reverse();
    
    // document.write("this is the shortest distance: ");
    // document.write(distances[endNode]);
    // document.write("<br>");
    // document.write("this is the path-way: ");
    // document.write(shortestPath);
    let results = {
      time: distances[endNode],
      path: shortestPath,
    };
    // return the shortest path & the end node's distance from the start node
      return results;
  };
  console.log(findShortestPath(graph, "A", "G"));

  exAD=exitTraffic(n),exBC=exitTraffic(n),exBE=exitTraffic(n),exCG=exitTraffic(n),exDF=exitTraffic(n),exAC=exitTraffic(n);

}



/////

// var canvas=document.querySelector('canvas');
// var c=canvas.getContext('2d');
// function make(){
//     //make source and dest
// c.fillText('A',141,19);
// c.fillText('G',141,139);
// c.fillText('C',141,65);
// c.fillText('B',49,65);//x moves with twice the speed of y
// c.fillText('D',233,65);
// c.fillText('E',49,93);
// c.fillText('F',233,93);
// c.fillStyle='rgb(255,0,0,0.3)';
// //c.font("20px Georgia");
// c.fillRect(135,10,20,10);//1
// c.fillRect(135,56,20,10);//3
// c.fillRect(135,130,20,10);//7
// c.fillRect(44,57,20,10);//2
// c.fillRect(225,57,20,10);//4
// c.fillRect(44,85,20,10);//5
// c.fillRect(226,85,20,10);//6

// //make lines
// c.beginPath();
// c.moveTo(143,20);//1 bottom
// c.lineTo(143,57);//3 up

// c.moveTo(143,66);//3 bottom
// c.lineTo(143,132);//7 up
// c.moveTo(143,20);
// c.lineTo(64,57);//2 diagonal
// c.moveTo(64,62);//2 side
// c.lineTo(135,62);//3 side
// c.moveTo(155,62);//3 side
// c.lineTo(225,62);//4 side
// c.moveTo(143,20);
// c.lineTo(225,57);//4 diagonal
// c.moveTo(54,67);//2 bottom
// c.lineTo(54,85);//5 up
// c.moveTo(236,67);//4 bottom
// c.lineTo(236,85);//6 up
// c.moveTo(64,95);//5 bottom
// c.lineTo(143,132);//7 up
// c.moveTo(226,95);
// c.lineTo(143,132);
// c.stroke();
// }
// function main12(){
    
//     c.beginPath();
//     c.moveTo(143,20);
//     c.lineTo(64,57);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main23(){
//     c.beginPath();
//     c.moveTo(64,62);
//     c.lineTo(135,62);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main37(){
//     c.beginPath();
//     c.moveTo(143,66);
//     c.lineTo(143,132);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main14(){
//     c.beginPath();
//     c.moveTo(143,20);
//     c.lineTo(225,57);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main34(){
//     c.beginPath();
//     c.moveTo(155,62);
//     c.lineTo(225,62);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main25(){
//     c.beginPath();
//     c.moveTo(64,95);
//     c.lineTo(143,132);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main57(){
//     c.beginPath();
//     c.moveTo(64,95);
//     c.lineTo(143,132);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main25(){
//     c.beginPath();
//     c.moveTo(54,67);
//     c.lineTo(54,85);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main46(){
//     c.beginPath();
//     c.moveTo(236,67);
//     c.lineTo(236,85);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// function main67(){
//     c.beginPath();
//     c.moveTo(226,95);
//     c.lineTo(143,132);
//     c.strokeStyle='blue';
//     c.stroke();
// }
// make();



function getInput(){
  cnum=document.getElementById("carnum").value;
  solve();  flag++;
}