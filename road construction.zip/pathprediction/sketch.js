function funcl( n){
    return (n/5.0)+4;
  }
  
  function funcr( n){
    return (n/12.0)+7;
  }
  
  function trafficelimination( n){
    if(n<=100){
      n/=1.2;
    }
    else if(n>100){
      n/=2;
    }
    else if(n>500){
      n/=3;
    }
    else{
      n/=10;
    }
    return n;
  }
  

  function solve(){
    var flag=1;
  
   var x=1;  
    var r=50,l=100;
    var mapApi=25;//to get answer for highway
    var midroad=2;
    var prethinl=document.getElementById("NOVLR").value;
    var prethinr=document.getElementById("NOVRR").value;
    var thickroad=mapApi;
    var lb=1,ub=50;
    var z=document.getElementById("NOV").value;
    var left=0,right=0;
  
    while(z<1000){
      // console.log(prethinl+" "+left+endl;
      // console.log(prethinr+" "+right+endl;
    var thinroadl=funcl(prethinl-=left);//NMST
    var thinroadr=funcr(prethinr-=right);//NMST
  
    var thickRThinR=thinroadr+thickroad;
    var thickLThinL=thinroadl+thickroad;
  
    var onlythin=thinroadl+thinroadr+midroad;
    var onlythick=thickroad*2+midroad;
    
    var mini=thickRThinR;
  
    if(mini>thickLThinL) mini=thickLThinL;
    if(mini>onlythin) mini=onlythin;
    if(mini>onlythick) mini=onlythick;
    
    if(mini==thickRThinR) {prethinr+=x;flag=1;}
    else if(mini==thickLThinL) {prethinl+=x;flag=2;}
    else if(mini== onlythin) {prethinl+=x;prethinr+=x;flag=3;}
    else flag=4;
    if(flag==4)
    console.log("thickRThinR: "+  thickRThinR);
    console.log("thickLThinL: "+thickLThinL);
    console.log("onlythin: "+onlythin);
    console.log("onlythick: "+onlythick);
  
    if(flag==1)   document.getElementById("path").innerHTML =("MinTime: "+mini.toPrecision(4)+" "+ "Minimum Path: thickRThinR"); 
    else if(flag==2)  document.getElementById("path").innerHTML =("MinTime: "+mini.toPrecision(4)+ " "+"Minimum Path::thickLThinL");
    else if(flag==3) document.getElementById("path").innerHTML =("MinTime: "+mini.toPrecision(4)+ " "+ "Minimum Path: onlythin"); 
    else if(flag==4)  document.getElementById("path").innerHTML =("MinTime "+mini.toPrecision(4)+ " "+"Minimum Path: onlythick"); 
  

    if(flag==1)   document.getElementById("path1").innerHTML =("N0, WE DONT NEED TO CONSTRUCT THIS ROAD TO REDUCE TRAFFIC"); 
    else if(flag==2)  document.getElementById("path1").innerHTML =("YES", "WE DONT NEED TO CONSTRUCT THIS ROAD TO REDUCE TRAFFIC");
    else if(flag==3) document.getElementById("path1").innerHTML =("N0, WE DONT NEED TO CONSTRUCT THIS ROAD TO REDUCE TRAFFIC"); 
    else if(flag==4)  document.getElementById("path1").innerHTML =("YES", "WE DONT NEED TO CONSTRUCT THIS ROAD TO REDUCE TRAFFIC"); 
     
  
    
    console.log("x: "+x );
      x=(rand() % (ub - lb + 1)) + lb;
      left=trafficelimination(thinroadl);
      right = trafficelimination(thinroadr);
      z++;
    }
  
   
  }
  function average( a, b){
    return (a+b)/2.0;
  }
//   function paradox(){
  
//     var n=87;
//     while(n<85){
//     var thickroad=25;
//     var midroad=2;
//     var thinroadl=funcl(n);//NMST
//     var thinroadr=funcr(n);//NMST
//     var onlythin=thinroadl+thinroadr+midroad;
//     var alternater=funcl(n/2)+thickroad;
//     var alternatel=funcr(n/2)+thickroad;
//     var alt=average(alternatel,alternater);
//     console.log("onlythin: "+onlythin+"  ");
//     if(onlythin>alt) console.log("remove onlythin "+"n: "+n);
//       n++;
//     }
        // var n;cin>>n; }
  
    // paradox();

    function setup() {
        createCanvas(600, 500);
      }
     
      
      function draw() {
        background(18, 80, 120);
        strokeWeight(8);
        stroke(255, 255, 0);
        line(100, 250, 290, 345);
        line(300, 135, 500, 250);
        strokeWeight(20);
        stroke(127, 255, 0);
        line(100, 250, 300, 135);
        line(290, 345, 500, 250);
        stroke(255, 0, 0);
        line(300, 135, 290, 345);
        strokeWeight(5);
        stroke(0, 0, 0);
        fill(255, 140, 0);
        circle(100, 250, 50);
        circle(500, 250, 50);
        circle(300, 135, 40);
        circle(290, 345, 40);
        strokeWeight(1);
        textSize(25);
        fill(0, 0, 0);
        text("A", 93, 255);
        text("B", 492, 257);
        text("C", 293, 142);
        text("D", 282, 352);
      }
      